# Changelog  
  
## FixPluginTypesSerialization [1.1.3]  
  
- Rebuilt project from https://github.com/xiaoxiao921/FixPluginTypesSerialization  
  - Might fix issues idk.
  
## FixPluginTypesSerialization [1.1.2]  
  
- Rebuilt project from https://github.com/xiaoxiao921/FixPluginTypesSerialization  
  - Should fix any issues people were having after deleting their config file.  
     